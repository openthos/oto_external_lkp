#!/system/xbin/sh
uiautomator runtest flashmaster.jar -c com.autoTestUI.flashmaster
