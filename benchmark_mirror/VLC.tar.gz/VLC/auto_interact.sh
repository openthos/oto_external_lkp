#!/system/xbin/sh
uiautomator runtest VLC.jar -c com.autoTestUI.VLC
