#!/system/xbin/sh
uiautomator runtest printerhp.jar -c com.autoTestUI.printerhpTest1
