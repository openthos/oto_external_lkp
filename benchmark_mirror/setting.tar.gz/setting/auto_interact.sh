#!/system/xbin/sh
uiautomator runtest setting.jar -c com.autoTestUI.setting
