#!/system/xbin/sh
uiautomator runtest wandoujia.jar -c com.autoTestUI.wandoujia
