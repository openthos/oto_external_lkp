#!/system/xbin/sh
uiautomator runtest baiduyun.jar -c com.autoTestUI.baiduyun
