#!/system/xbin/sh
uiautomator runtest taskmanager.jar -c com.autoTestUI.taskmanagerTest1
