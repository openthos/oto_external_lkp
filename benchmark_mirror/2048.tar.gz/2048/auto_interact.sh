#!/system/xbin/sh
uiautomator runtest 2048.jar -c com.autoTestUI.yx_2048
