#!/system/xbin/sh
uiautomator runtest fm.jar -c com.autoTestUI.fm
