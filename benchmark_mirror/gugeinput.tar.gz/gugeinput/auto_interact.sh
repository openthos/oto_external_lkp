#!/system/xbin/sh
uiautomator runtest gugeinput.jar -c com.autoTestUI.gugeinput
