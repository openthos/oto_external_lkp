#!/system/xbin/sh
uiautomator runtest fotoFinder.jar -c com.autoTestUI.fotoFinderTest1
