#!/system/xbin/sh
sleep 30
