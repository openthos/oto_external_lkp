#!/system/xbin/sh
for i in {1..60} 
do echo $i 
date
sleep 1
done



