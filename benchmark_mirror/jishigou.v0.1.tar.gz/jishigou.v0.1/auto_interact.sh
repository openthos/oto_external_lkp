#!/system/xbin/sh
for i in `seq 1 100`
do
echo $i
date
sleep 1
done
