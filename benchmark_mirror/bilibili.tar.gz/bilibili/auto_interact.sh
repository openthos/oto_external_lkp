#!/system/xbin/sh
uiautomator runtest bilibiliTest.jar -c com.autoTestUI.bilibiliTest1
