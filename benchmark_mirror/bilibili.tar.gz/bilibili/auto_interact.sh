#!/system/xbin/sh
uiautomator runtest bilibili.jar -c com.autoTestUI.bilibiliTest1
