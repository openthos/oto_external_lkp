#!/system/xbin/sh
uiautomator runtest tairuiTest.jar -c com.autoTestUI.tairuiTest1
