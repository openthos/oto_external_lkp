#!/system/xbin/sh
uiautomator runtest tairui.jar -c com.autoTestUI.tairuiTest1
