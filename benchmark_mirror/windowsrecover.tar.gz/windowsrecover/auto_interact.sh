#!/system/xbin/sh
uiautomator runtest windowsrecover.jar -c com.autoTestUI.windowsrecoverTest1
