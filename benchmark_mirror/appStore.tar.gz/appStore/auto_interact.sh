#!/system/xbin/sh
uiautomator runtest appStore.jar -c com.autoTestUI.appStore
