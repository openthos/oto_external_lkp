#!/system/xbin/sh
uiautomator runtest appStore.jar -c com.appStore.appStoreTest1
