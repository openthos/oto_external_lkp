#!/system/xbin/sh
uiautomator runtest music.jar -c com.autoTestUI.music
