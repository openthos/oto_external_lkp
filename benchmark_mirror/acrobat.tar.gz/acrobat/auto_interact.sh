#!/system/xbin/sh
uiautomator runtest acrobat.jar -c com.autoTestUI.acrobat
