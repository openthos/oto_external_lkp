#!/system/xbin/sh
uiautomator runtest autocad.jar -c com.autoTestUI.autocadTest1
