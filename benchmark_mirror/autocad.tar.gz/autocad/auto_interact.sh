#!/system/xbin/sh
uiautomator runtest autocadTest.jar -c com.autoTestUI.autocadTest1
