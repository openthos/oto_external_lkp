#!/system/xbin/sh
uiautomator runtest gdmap.jar -c com.autoTestUI.gdmap
