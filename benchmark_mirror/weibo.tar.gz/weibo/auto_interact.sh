#!/system/xbin/sh
uiautomator runtest weibo.jar -c com.autoTestUI.weiboTest1
