#!/system/xbin/sh
uiautomator runtest system_ui.jar -c com.autoTestUI.system_ui
