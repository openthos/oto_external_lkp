#!/system/xbin/sh
uiautomator runtest fennec.jar -c com.autoTestUI.fennec
