#!/system/xbin/sh
uiautomator runtest wps.jar -c com.autoTestUI.wps
