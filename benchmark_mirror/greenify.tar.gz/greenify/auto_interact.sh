#!/system/xbin/sh
uiautomator runtest greenify.jar -c com.autoTestUI.greenify
