#!/system/xbin/sh
uiautomator runtest yingsuo.jar -c com.autoTestUI.yingsuoTest1
