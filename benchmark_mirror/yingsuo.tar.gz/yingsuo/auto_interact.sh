#!/system/xbin/sh
uiautomator runtest yingsuoTest.jar -c com.autoTestUI.yingsuoTest1
