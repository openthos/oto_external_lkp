#!/system/xbin/sh
uiautomator runtest Taiwan.jar -c com.autoTestUI.TaiwanTest1
