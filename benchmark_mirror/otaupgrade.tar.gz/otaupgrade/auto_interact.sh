#!/system/xbin/sh
uiautomator runtest otaupgrade.jar -c com.autoTestUI.otaupgradeTest1
