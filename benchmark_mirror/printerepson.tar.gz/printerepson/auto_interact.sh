#!/system/xbin/sh
uiautomator runtest printerepson.jar -c com.autoTestUI.printerepsonTest1
