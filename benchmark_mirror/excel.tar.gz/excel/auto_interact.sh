#!/system/xbin/sh
uiautomator runtest excel.jar -c com.autoTestUI.excel
