#!/system/xbin/sh
uiautomator runtest editor920.jar -c com.autoTestUI.editor920
