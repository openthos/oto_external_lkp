#!/system/xbin/sh
uiautomator runtest outlook.jar -c com.autoTestUI.outlook
