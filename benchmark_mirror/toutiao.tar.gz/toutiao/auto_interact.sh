#!/system/xbin/sh
uiautomator runtest toutiao.jar -c com.autoTestUI.toutiao
