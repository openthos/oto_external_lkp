#!/system/xbin/sh
uiautomator runtest wpspro.jar -c com.autoTestUI.wpspro
