#!/system/xbin/sh
uiautomator runtest Skype.jar -c com.autoTestUI.SkypeTest1
