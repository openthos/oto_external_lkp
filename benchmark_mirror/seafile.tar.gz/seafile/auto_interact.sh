#!/system/xbin/sh
uiautomator runtest seafile.jar -c com.autoTestUI.seafile
