#!/system/xbin/sh
uiautomator runtest taijie_video.jar -c com.autoTestUI.taijie_video
