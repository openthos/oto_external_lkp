#!/system/xbin/sh
uiautomator runtest kindle.jar -c com.autoTestUI.kindle
