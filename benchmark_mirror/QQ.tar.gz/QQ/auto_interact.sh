#!/system/xbin/sh
uiautomator runtest QQ.jar -c com.autoTestUI.qq
