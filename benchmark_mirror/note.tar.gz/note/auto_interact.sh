#!/system/xbin/sh
uiautomator runtest note.jar -c com.autoTestUI.note
