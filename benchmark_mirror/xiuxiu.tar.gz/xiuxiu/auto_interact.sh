#!/system/xbin/sh
uiautomator runtest xiuxiu.jar -c com.autoTestUI.meitu
