#!/system/xbin/sh
uiautomator runtest tencent_video.jar -c com.autoTestUI.tencent_video
