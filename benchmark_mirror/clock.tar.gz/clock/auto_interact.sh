#!/system/xbin/sh
uiautomator runtest clock.jar -c com.autoTestUI.clock
