#!/system/xbin/sh
uiautomator runtest authoritymanager.jar -c com.autoTestUI.authoritymanagerTest1
