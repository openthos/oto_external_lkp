#!/system/xbin/sh
uiautomator runtest IThome.jar -c com.autoTestUI.IThome
