#!/system/xbin/sh
uiautomator runtest pod.jar -c com.autoTestUI.podTest1
