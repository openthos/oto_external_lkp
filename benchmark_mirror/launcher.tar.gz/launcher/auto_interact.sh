#!/system/xbin/sh
uiautomator runtest launcher.jar -c com.autoTestUI.launcher
