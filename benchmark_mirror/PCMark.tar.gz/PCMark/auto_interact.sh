#!/system/xbin/sh
uiautomator runtest PCMarkTest.jar -c com.autoTestUI.PCMarkTest1
