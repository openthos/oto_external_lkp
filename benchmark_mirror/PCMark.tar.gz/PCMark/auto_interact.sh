#!/system/xbin/sh
uiautomator runtest PCMark.jar -c com.autoTestUI.PCMarkTest1
