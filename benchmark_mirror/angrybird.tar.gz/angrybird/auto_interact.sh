#!/system/xbin/sh
uiautomator runtest angrybird.jar -c com.autoTestUI.angrybird
