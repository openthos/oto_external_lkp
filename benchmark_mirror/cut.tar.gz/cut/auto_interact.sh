#!/system/xbin/sh
uiautomator runtest cut.jar -c com.autoTestUI.cutTest1
