#!/system/xbin/sh
uiautomator runtest cntvhd.jar -c com.autoTestUI.cntvhdTest
