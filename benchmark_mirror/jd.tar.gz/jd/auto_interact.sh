#!/system/xbin/sh
uiautomator runtest jd.jar -c com.autoTestUI.jd
