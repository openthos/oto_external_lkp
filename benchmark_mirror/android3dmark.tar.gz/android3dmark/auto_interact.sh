#!/system/xbin/sh
uiautomator runtest android3dmark.jar -c com.autoTestUI.android3dmark
