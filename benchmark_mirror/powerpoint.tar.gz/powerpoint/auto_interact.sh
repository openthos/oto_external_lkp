#!/system/xbin/sh
uiautomator runtest powerpoint.jar -c com.autoTestUI.powerpoint
