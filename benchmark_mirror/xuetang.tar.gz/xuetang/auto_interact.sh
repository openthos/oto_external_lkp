#!/system/xbin/sh
uiautomator runtest xuetang.jar -c com.autoTestUI.xuetang
