#!/system/xbin/sh
uiautomator runtest printercanon.jar -c com.autoTestUI.printercanonTest1
