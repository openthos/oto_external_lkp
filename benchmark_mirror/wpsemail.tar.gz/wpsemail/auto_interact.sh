#!/system/xbin/sh
uiautomator runtest wpsemail.jar -c com.autoTestUI.wpsemail
