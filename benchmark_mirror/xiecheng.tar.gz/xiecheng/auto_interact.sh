#!/system/xbin/sh
uiautomator runtest xiecheng.jar -c com.autoTestUI.xiecheng
