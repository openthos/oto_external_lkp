#!/system/xbin/sh
uiautomator runtest OSmonitor.jar -c com.autoTestUI.OSmonitor
