#!/system/xbin/sh
uiautomator runtest taobao.jar -c com.autoTestUI.taobao
