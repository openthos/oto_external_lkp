#!/system/xbin/sh
uiautomator runtest tuniu.jar -c com.autoTestUI.tuniu
