#!/system/xbin/sh
uiautomator runtest czfilemanager.jar -c com.autoTestUI.czfilemanager
