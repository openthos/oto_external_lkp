#!/system/xbin/sh
uiautomator runtest word.jar -c com.autoTestUI.microsoft_word
