#!/system/xbin/sh
uiautomator runtest calc.jar -c com.autoTestUI.calc
