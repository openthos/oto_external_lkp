#!/system/xbin/sh
uiautomator runtest gallery.jar -c com.autoTestUI.gallery
