#!/system/xbin/sh
uiautomator runtest yx_2048.jar -c com.autoTestUI.yx_2048
