#!/system/xbin/sh
uiautomator runtest YinxiangNote.jar -c com.autoTestUI.YinxiangNoteTest1
