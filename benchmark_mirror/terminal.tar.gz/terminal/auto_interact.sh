#!/system/xbin/sh
uiautomator runtest terminal.jar -c com.autoTestUI.terminal
