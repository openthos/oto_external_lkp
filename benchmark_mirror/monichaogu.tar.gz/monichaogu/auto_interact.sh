#!/system/xbin/sh
uiautomator runtest monichaogu.jar -c com.autoTestUI.monichaoguTest1
