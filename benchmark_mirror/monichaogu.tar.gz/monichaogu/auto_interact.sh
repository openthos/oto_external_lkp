#!/system/xbin/sh
uiautomator runtest monichaoguTest.jar -c com.autoTestUI.monichaoguTest1
