#!/system/xbin/sh
uiautomator runtest quickpicker.jar -c com.autoTestUI.quickpicker
