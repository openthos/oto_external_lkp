#!/system/xbin/sh
uiautomator runtest candycrushTest.jar -c com.autoTestUI.candycrushTest1
