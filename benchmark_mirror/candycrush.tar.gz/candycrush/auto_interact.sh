#!/system/xbin/sh
uiautomator runtest candycrush.jar -c com.autoTestUI.candycrushTest1
