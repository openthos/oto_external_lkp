#!/system/xbin/sh
uiautomator runtest printermopria.jar -c com.autoTestUI.printermopriaTest1
