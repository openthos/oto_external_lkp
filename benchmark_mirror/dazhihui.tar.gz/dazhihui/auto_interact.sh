#!/system/xbin/sh
uiautomator runtest dazhihui.jar -c com.autoTestUI.dazhihui
