#!/bin/bash -x
java -jar testuiauto.jar 192.168.0.55 5555  otoAutoTest.jar aaa
