#!/system/xbin/sh
uiautomator runtest wechat.jar -c com.autoTestUI.wechat
