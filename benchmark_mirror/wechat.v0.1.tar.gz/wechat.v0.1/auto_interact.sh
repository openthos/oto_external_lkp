#!/system/xbin/sh
uiautomator runtest /data/ubuntu/lkp/benchmarks/wechat/wechat.jar -c com.autoTestUI.wechat
