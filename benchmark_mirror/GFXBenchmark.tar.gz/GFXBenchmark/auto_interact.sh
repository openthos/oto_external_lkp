#!/system/xbin/sh
uiautomator runtest GFXBenchmarkTest.jar -c com.autoTestUI.GFXBenchmarkTest1
