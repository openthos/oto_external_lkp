#!/system/xbin/sh
uiautomator runtest GFXBenchmark.jar -c com.autoTestUI.GFXBenchmarkTest1
