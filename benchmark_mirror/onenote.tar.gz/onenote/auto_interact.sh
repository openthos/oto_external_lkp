#!/system/xbin/sh
uiautomator runtest onenote.jar -c com.autoTestUI.onenote
