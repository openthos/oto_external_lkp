#!/system/xbin/sh
uiautomator runtest editor.jar -c com.autoTestUI.editorTest1
