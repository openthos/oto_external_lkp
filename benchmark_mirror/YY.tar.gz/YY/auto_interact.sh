#!/system/xbin/sh
uiautomator runtest YY.jar -c com.autoTestUI.YY
