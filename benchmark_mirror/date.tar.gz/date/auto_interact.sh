#!/system/xbin/sh
uiautomator runtest date.jar -c com.autoTestUI.date
