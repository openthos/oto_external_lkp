#!/system/xbin/sh
uiautomator runtest email.jar -c com.autoTestUI.email
