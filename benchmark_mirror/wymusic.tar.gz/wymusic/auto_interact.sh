#!/system/xbin/sh
uiautomator runtest wymusic.jar -c com.autoTestUI.wyiyunmusic
