#!/system/xbin/sh
uiautomator runtest localprinter.jar -c com.autoTestUI.localprinterTest1
