#!/system/xbin/sh
uiautomator runtest Yamaxun.jar -c com.autoTestUI.YamaxunTest1
