#!/system/xbin/sh
uiautomator runtest sparkle.jar -c com.autoTestUI.sparkleTest1
