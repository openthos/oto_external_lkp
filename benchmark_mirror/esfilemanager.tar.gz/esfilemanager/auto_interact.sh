#!/system/xbin/sh
uiautomator runtest esfilemanager.jar -c com.autoTestUI.esfilemanager
