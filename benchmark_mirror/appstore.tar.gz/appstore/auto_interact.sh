#!/system/xbin/sh
uiautomator runtest appstore.jar -c com.autoTestUI.appstoreTest1
